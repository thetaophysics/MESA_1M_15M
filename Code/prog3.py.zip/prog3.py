# Import libraries 
import numpy as np
import matplotlib.pyplot as plt
from numpy import *
import os
import mesa_reader as mr
from scipy.optimize import curve_fit

# PATH DIRECTORY
PATH1 = '/Users/tranghuynh/Dropbox/LSU/Fall_2022/ASTR4750/project3/1M_star/LOGS/'
PATH15 = '/Users/tranghuynh/Dropbox/LSU/Fall_2022/ASTR4750/project3/1M_star/LOGS_15/'
f1 = 'history.data'
f15 = 'history.data'
profile1 = 'profileXX.data'
profile15 = 'profile17.data'

################################### BODY ##########################################
# Model for 1 solar mass
os.chdir(PATH1)
if os.path.exists(PATH1):
    h = mr.MesaData(f1)

#Import data for 1 solar mass
ages = h.data('star_age')
log_dt = h.data('log_dt')
log_Teff = h.data('log_Teff')
log_L = h.data('log_L')
rho_c = h.data('center_Rho')
T_c = h.data('center_T')
print(shape(T_c), '1M')
print('T_c =', T_c)
print('\n')
# Model for 15 solar mass
os.chdir(PATH15)
if os.path.exists(PATH15):
    h15 = mr.MesaData(f15)

# Import data for 15 solar mass
ages15 = h15.data('star_age')
log_dt15 = h15.data('log_dt')
log_Teff15 = h15.data('log_Teff')
log_L15 = h15.data('log_L')
rho_c15 = h15.data('center_Rho')
T_c15 = h15.data('center_T')
print(shape(T_c15), '15M')
print('T_c15 = ', T_c15)


# HR Diagram plot for 1M
plt.figure(1)
plt.plot(h.log_Teff, h.log_L, 'b-', label = ' 1 solar mass')
plt.plot(h15.log_Teff, h15.log_L, 'r-', label = ' 15 solar mass')
plt.title('HR Diagram for 1M and 15M models')
plt.xlabel('log Effective Temperature')
plt.ylabel('log Luminosity')
legend = plt.legend(loc='lower right',shadow='True')
plt.minorticks_on()
plt.show()


# Evolution of central density versus central temperature
plt.figure(2)
plt.plot(T_c, rho_c,'b-', label = ' 1 solar mass' )
plt.plot(T_c15, rho_c15,'r-', label = ' 15 solar mass' )
plt.title('Evolution of Central Density versus Central Temperature ')
plt.xlabel(' Central Temperature')
plt.ylabel(' Cenral Density')
legend = plt.legend(loc='lower right',shadow='True')
plt.minorticks_on()
plt.show()

#Part b
# Load the last profile.data
# profile17 = 'profile17.data'
# os.chdir(PATH)
# if os.path.exists(PATH):
#     p = mr.MesaLogDir(PATH)

#Retrieve
# P = 10 ** p.logP 
# rho = 10 ** p.logRho
# print (P, rho)


# # part b
# # Load the last profile.data
# profile17 = 'profile17.data'
# os.chdir(PATH15)
# if os.path.exists(PATH15):
#     p = mr.MesaData(profile17)

# #Retrieve
# P15 = p.logP 
# rho15 = 10 ** p.logRho
# # print (P, rho)
# # print(shape(P15), shape(rho15))
# trunc_P15 = P15[:439]
# trunc_rho15 = rho15[:439]
# # print(shape(trunc_P15), shape(trunc_rho15))

# #Define EOS function
# def eos(rho, gamma):
#     return rho**gamma
# y_mod = eos(trunc_rho15, 0.05) #*1e10
# #Perform the fit	
# fit,cov = curve_fit(eos,trunc_rho15,trunc_P15)

# # print('The best-fit model is: ', fit)
# gamma = fit 
# print(gamma)
# #Polytropic Index
# n = 1/(gamma - 1) 
# print(n)

# plt.figure(1)
# # plt.plot(trunc_rho15, trunc_P15,'r-', label='data')
# plt.plot(trunc_rho15, y_mod, 'b-', label = 'model' )
# # plt.plot(trunc_rho15, eos(trunc_rho15, *fit), 'g--', label='fit-with-bounds') 
# plt.title('Equation of State when x_central_mass_fraction > 0.6')
# plt.xlabel(' Density ')
# plt.ylabel(' Pressure ')
# legend = plt.legend(loc='lower right',shadow='True')
# plt.show()








